import { Customer3 } from "../customer";



let customer = new  Customer3("John", "Smith", 30)

customer.greeter();
console.log(customer.getAge());