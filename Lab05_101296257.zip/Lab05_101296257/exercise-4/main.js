"use strict";
exports.__esModule = true;
var customer_1 = require("../customer");
var customer = new customer_1.Customer3("John", "Smith", 30);
customer.greeter();
console.log(customer.getAge());
